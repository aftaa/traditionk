<?php
/**
 * Created by PhpStorm.
 * User: Maxim Gabidullin <after@ya.ru>
 * Date: 06.12.2018
 * Time: 21:33
 */

/** @var int $number */

?>

Извлечено из базы данных в сессию: <?= $number ?>