<?php
/**
 * Created by PhpStorm.
 * User: Maxim Gabidullin <after@ya.ru>
 * Date: 06.12.2018
 * Time: 20:52
 */

/** @var int $number */

?>

Число из сессии: <?= $number ?>
