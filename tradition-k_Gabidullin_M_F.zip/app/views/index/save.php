<?php
/**
 * Created by PhpStorm.
 * User: Maxim Gabidullin <after@ya.ru>
 * Date: 06.12.2018
 * Time: 21:32
 */

/** @var int $number */

?>

Сохранено в базу данных: <?= $number ?>
