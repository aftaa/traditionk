<?php
/**
 * Created by PhpStorm.
 * User: Maxim Gabidullin <after@ya.ru>
 * Date: 06.12.2018
 * Time: 17:29
 */

return [
    'appFolder' => 'app/',
    'pdo' => [
        'dsn' => 'mysql:dbname=tk;host=localhost',
        'user' => 'tk',
        'pass' => 'tk',
    ],
];